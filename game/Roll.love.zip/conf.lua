function love.conf(t)
    io.stdout:setvbuf("no")
end